﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_06
{
    internal static class Borrower <T,U>
    {
        static List<T> borrower;
        static List<U> b;
    }
}
